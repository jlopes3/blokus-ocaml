(*

FPSE Assignment 4
 
Name                  : Jonathon Lopes
List of Collaborators :

*)

open Core


(*
  In this assignment you will implement a simple n-gram model.  We will also give you some template code to give you a basis for an elegant and general library for modeling n-grams.

  Part I consists of these library routines, and Part II will be to develop a command-line tool to build and use an n-gram model which makes use of your library.

  Using the n-gram model of sequences and probabilities, we'll take in some sequence of items, and then use it as a basis to generate more similar sequences (for example, sentences of words, lists of numbers, etc.), or evaluate the likelihood of seeing particular sequences.

  First we need some helper functions and definitions.

*)

(* Part I consists of the following 6 Exercises *)

(*
  Exercise 1:

  Given a list of some type, and a positive integer `n`, produce a list of contiguous subsequences of length `n` of the original list. If `n` is greater than the length of the input, return an empty list.

  E.G.
    chunks 3 [1; 2; 3; 4; 5] =
      [ [1;2;3]; [2;3;4]; [3;4;5] ]

    chunks 2 ["a"; "b"; "c"; "d"; "e"] =
      [ ["a";"b"]; ["b";"c"]; ["c";"d"]; ["d";"e"] ]

      chunks 3 [1; 2] = []
    else if (length > List.length total) then []
*)
let rec list_section_helper (start: int) (length: int) (curr: int) (total: 'a list): 'b list =
  if (curr > (start + length - 1)) then []
  else if (curr > (start - 1)) then (List.nth_exn total curr) :: list_section_helper start length (curr + 1) (total)
  else list_section_helper start length (curr + 1) (total);;

let list_section (start: int) (length: int) (total: 'b list): 'b list =
  list_section_helper start length 0 total;;

let rec chunks_helper (n: int) (index: int) (l: 'a list): 'a list list =
  if (index > ((List.length l) - n)) then []
  else (list_section index n l) :: chunks_helper n (index + 1) l;; 

let chunks (n: int) (l: 'a list): 'a list list =
  chunks_helper n 0 l;;

(*
  Exercise 2:

  Given a non-empty list of some type, return a pair of the last element, and a list of all previous elements. This should take O(n) time.

  E.G.
    split_last [1;2;3] = (3, [1;2])
*)
let split_last (l: 'a list): 'a * 'a list =
  (List.hd_exn (List.rev l), List.rev (List.tl_exn (List.rev l)));;


(*
Exercise 3:

Here we will make a generic method for making map keys which are lists of some underlying element. 

Given a data type module Elt which can be used as the key for a map (Map.Key module type in Core), fill in the following functor to make a map key data type module for a *list* of Elt's.  
Recall that the Map.Key module type needs 
a type `t`, 
a `compare` on it 
and the to/from s-expression conversions over `t`
: https://ocaml.org/p/core/v0.15.0/doc/Core/Map_intf/module-type-Key/index.html.
*)
module List_key (Elt: Map.Key): (Map.Key with type t = Elt.t list) = struct
  (*
  ... YOUR IMPLEMENTATION HERE ... 
  *)
  type t = Elt.t list [@@deriving compare, sexp]
end

(*
We will need randomness for this code, which can make things hard to test. To make it repeatable, we will abstract away the randomizer as another parameter, of module type `Randomness`.

Note that the standard `Core.Random` module is compatible with this module type, but you could also provide alternative definitions which are deterministic, give more debug info, guarantee a certain sequence of numbers, log to stderr, etc.
*)
module type Randomness = sig
  (*
  Given a maximum integer value, return a pseudorandom integer from 0 (inclusive) to this value (exclusive).
  *)
  val int : int -> int
end

(*
Exercise 4:

Given a multiset aka bag, select one element from it with uniform probability (i.e. so that elements which appear multiple times should have a higher chance to be picked). Or, if the bag is empty, return None.
  
  See the (weighted) reservoir sampling algorithms for a simple potential approach to this.
  
  Use `Core.Bag` for your bag. This operation should not be destructive or mutate the bag, it should just extract a random element. Be aware that Core.Bag is a mutable data structure.  Also be aware of the `'a Bag.Elt.t` type, which signifies a particular element within the Bag (distinguishing it from other, possibly equal elements).
  
  Several Bag functions take and return `'a Bag.Elt.t` values so look at the documentation for `Bag.Elt` to see how to e.g. extract the underlying value.
  
  Note that `Bag.choose` does *not* satisfy this definition;  it simply picks the first element always.
  
  Note we use a shorthand notation for first-class modules not covered in lecture: the parameter R here is a first-class module which has already been unpacked from value-space to module-space.  Similarly, sample can be invoked as e.g. `sample (module Random) ...`
  
  *)
  let sample (module R: Randomness) (b: 'a Bag.t): 'a option =
    if (Core.Bag.length b = 0) then None 
    else Some(List.nth_exn (Core.Bag.to_list b) (R.int (Core.Bag.length b)));;
    
    (* Exercise 5:
    
    Fill out the skeleton of the module N_grams below to make a common probabilistic model of sequences, the n-gram model, also called the Markov model.
    
    The general intuition is simple: if we want to be able to predict what comes next in a sequence of items, we can probably do so on the basis of the elements which preceeded it. Moreover, we can 
      probably ignore parts of the sequence which came _far_ before the element we want to predict, and focus our attention on the immediately previous couple of items.
    
    Consider sentences of words in english text, a very common type of sequence to apply this approach to. If we are given that the word we want to predict came after:
    
    "take this boat for a spin out on the" ???
    
    Then we could say that "water" is more likely than "town" to follow. If we have less context, say only 2 words:
    
    "on the" ???
    
    We will naturally make a poorer approximation of the true distribution, but it may be sufficient for some purposes anyway, and will be easier to estimate.  How can we estimate the actual distribution of words efficiently, then?
    
    We will need to take in some observed sequence of words or tokens, called a _corpus_.  Let's say we want to keep 2 words of context when predicting what comes next, based on the provided corpus. Then we can 
    just keep track of every 3-tuple of consecutive words in the input, and count how often they appear.
    
    For example, say we observe the triples
    
    ("take", "this", "boat"), ("this", "boat", "for"), ... ("on", "the", "water").
    
    Then, if we index these properly, we can predict what should follow ("on", "the") by just sampling randomly from among all the tuples which started with that prefix, and using the last element of the tuple as our prediction.  Naturally, words which appear more frequently in the context specified should then be given more weight, and words which do not appear in our corpus after the given sequence will not be chosen at all, so our prediction should be a reasonable estimate for the empirical distribution.
      
      If we instead count 5-tuples rather than 3-tuples, we can make better predictions with the greater context, which will then more closely match the true sequence properties. However, we will also be able to observe fewer unique 5-tuples overall than 3-tuples, which will mean we need greater amounts of data to properly use a larger n-gram size.
      
      
      Feel free to read these useful resources to better understand n-grams:
      - https://blog.xrds.acm.org/2017/10/introduction-n-grams-need/
      - https://web.stanford.edu/~jurafsky/slp3/slides/LM_4.pdf
      - https://medium.com/mti-technology/n-gram-language-model-b7c2fc322799
      
      
      First define a module which holds our main functionality specific to a particular orderable type we'll call `Token`. These tokens could be words (strings) of course, but could also be numbers, or DNA base pairs, etc.
      
      We also need randomness here, so we will abstract over it as well.
      *)
      module N_grams (Random: Randomness) (Token: Map.Key) = struct
        
        (*
        Define a module which is a Map satisfying the signature provided, so that sequences of tokens can be mapped to values.
        *)
        module Token_list_map : (Map.S with type Key.t = Token.t list) = Map.Make(List_key(Token));;
        (* remove ;; and fill in *)
        
        (*
        Based on how n-grams work, we will represent a probability distribution as mapping from prefixes of size `n`, to tokens which followed this prefix in our training corpus. The more times any particular token follows a prefix, the more likely it is to follow it again.
        
        Don't change this type; it is a map from token lists to bags of tokens.
        *)
        type distribution = (Token.t Bag.t) Token_list_map.t
        
        (*
        Given a positive integer `n` and a list of tokens, add each token to a new distribution as an element of the set corresponding to the (n-1)-gram which preceeds it.
        
        e.g. (informally diagramming the map/bag of a `distribution`)
        
        ngrams 2 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
        { 
          [1] -> {2}; 
          [2] -> {3; 2; 3};
          [3] -> {4; 1};
          [4] -> {4; 4; 2};
          |        |
          |        \------- ...was followed by each of these elements
          \-- this sequence (of length 1 in this example of 2-grams)  ...
          }
          
          ngrams 3 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
          {
            [1; 2] -> {3};
            [2; 3] -> {4; 1};
            [3; 4] -> {4};
            [4; 4] -> {4; 2};
            [4; 2] -> {2};
            [2; 2] -> {3};
            |        |
            |        \------- ...was followed by each of these elements
            \-- this sequence...
            }
            
            ngrams 1 [1; 2; 3; 4; 4; 4; 2; 2; 3; 1] =
            {
              [] -> {1; 2; 3; 4; 4; 4; 2; 2; 3; 1};
              |        |
              |        \------- ...was followed by each of these elements
              \-- this sequence...
              }
              *)

              let get_first (pair: 'a * 'b): 'a =
                let (r1, _) = pair in
                  r1;;
              
              let get_second (pair: 'a * 'b): 'b =
                let (_, r2) = pair in
                  r2;;
              
              let add_to_map (map: (Token.t Bag.t) Token_list_map.t) (pair: Token.t * Token.t list): (Token.t Bag.t) Token_list_map.t = 
                match (Map.find map (get_second pair)) with
                | Some(value) -> Map.set map ~key:(get_second pair) ~data:(Bag.of_list((Bag.to_list value) @ [(get_first pair)]))
                | None -> Map.set map ~key:(get_second pair) ~data:(Bag.of_list [(get_first pair)]);;
                
              let ngrams (n: int) (l: Token.t list): distribution =
                List.fold ~f:(add_to_map) ~init:(Token_list_map.empty) (List.map ~f:(split_last) (chunks n l));;
 
                
                (*
                
                Now, we can use the output of `ngrams` to create new, randomly sampled sequences.
                
                The arguments it expects are as follows:
                - an output from a call to `ngrams n` (above) representing a distribution
                - an integer for the maximum length of sequence to generate
                - a list of tokens (of length `n-1`) to kick off the random generation and sequence (consider it a 'seed' to look up in the distribution)
                
                It will then produce a sequence which is distributed according to the n-gram model it is given, terminating if either the resulting sequence reaches the maximum length, or when there are no observed
                  n-grams which could follow.
                
                *)

                let rec last_m_list_helper (count: int) (data: 'a list) (m: int) : 'a list =
                  if (Int.equal (count - 1) m) then []
                  else (last_m_list_helper (count + 1) data m) @ [List.nth_exn data ((List.length data) - count)];;

                (* Precondition: m <= data length *)
                let last_m_list (data: 'a list) (m: int) : 'a list =
                  last_m_list_helper 1 data m;;
                
                let rec sample_sequence_helper (dist: distribution) (max_length: int) (curr_ngram: Token.t list) (n: int): Token.t list =
                  if (Int.equal (List.length (curr_ngram)) max_length) then curr_ngram
                  else match Map.find dist (last_m_list curr_ngram n) with
                  | None -> curr_ngram
                  | Some(bag) -> match sample (module Random) bag with
                    | None -> curr_ngram (* unreachable *)
                    | Some(value) -> sample_sequence_helper (dist) (max_length) (curr_ngram @ [value]) n;;

                let sample_sequence (dist: distribution) ~(max_length: int) ~(initial_ngram: Token.t list): Token.t list =
                  sample_sequence_helper dist max_length (initial_ngram) (List.length initial_ngram);;
                  
                end (* of module N_grams *)
                
(*
Exercise 6:

Given a string, perform basic sanitization/normalization by taking the following steps:

- remove all characters not in the range [a-zA-Z0-9]
- convert all characters [A-Z] to lowercase

if the resulting string is empty, return None.
*)
let rec remove_nonalphanumeric_helper (input: string) (curr: int): string =
  if (Int.equal (String.length input) (curr)) then ""
  else if (Char.to_int input.[curr] > 47 && Char.to_int input.[curr] < 58) then ((Char.to_string input.[curr]) ^ remove_nonalphanumeric_helper input (curr + 1))
  else if (Char.to_int input.[curr] > 96 && Char.to_int input.[curr] < 122) then ((Char.to_string input.[curr]) ^ remove_nonalphanumeric_helper input (curr + 1))
  else remove_nonalphanumeric_helper input (curr + 1);;
  
let remove_nonalphanumeric (s: string): string =
  remove_nonalphanumeric_helper (String.lowercase s) 0;;
  
let sanitize (s: string): string option =
  match remove_nonalphanumeric s with
  | "" -> None
  | res -> Some (res);;       

  (* See ngrams.ml for part II.
  
  For any auxiliary functions needed in part II, put them here so they can
  be unit tested.  
  *)


(* Make a string from the file contents 
let make_string_from_file (file : string) : string = file |> In_channel.read_all;;
*)

(* Make a string into a list of strings *)
let make_list_from_string (curr: string) : string list = curr |> String.split_on_chars ~on: (['\t'; '\r'; '\n'; ' '; '\x0C']);;

let option_to_bool (input: string option) : bool =
  match input with
  | Some(_) -> true
  | None -> false;;

let option_to_no_option (input: string option) : string =
  match input with
  | Some(x) -> x
  | None -> "";; (* should be unreachable *)

let sanitize_all (strings : string list) : string list =
  List.map ~f:(option_to_no_option) (List.filter ~f:(option_to_bool) (List.map ~f:(sanitize) (strings)));;

  (*
  let file_to_sanitized_list (filename : string) : string list =
    make_string_from_file filename
    |> make_list_from_string
    |> sanitize_all;;
    *)
            

  (* SAMPLE CHOICE *)
  module SGrams = N_grams (Core.Random) (String)

  let add_to_string (input: string) (input2: string): string = input ^ " " ^ input2;;

  let remove_first_char (inputString: string): string =
    String.sub inputString ~pos:(1) ~len:(String.length inputString - 1);;

  let list_to_string (input: string list) : string = remove_first_char (List.fold ~f:(add_to_string) ~init:("") input);;

  let rec last_m_list_helper (count: int) (data: 'a list) (m: int) : 'a list =
    if (Int.equal (count - 1) m) then []
    else (last_m_list_helper (count + 1) data m) @ [List.nth_exn data ((List.length data) - count)];;

  let last_m_list (data: 'a list) (m: int) : 'a list =
    last_m_list_helper 1 data m;;

  let first_m_list (data: 'a list) (m: int) : 'a list =
    List.rev (last_m_list (List.rev data) m);;
    
    

(* Sample choicee if initial ngram is given 
  let sample_choice_initial (n: int) (input_file: string list) (sample_length: int) (initial_ngram: string list) =
    print_endline (list_to_string (first_m_list initial_ngram ((List.length initial_ngram) - n + 1) @ (SGrams.sample_sequence (SGrams.ngrams n input_file) ~max_length:(sample_length - (List.length initial_ngram) + n - 1) ~initial_ngram:(last_m_list initial_ngram (n - 1)))));;
    *)
        
  let random_ngram_start (key_list: string list list) : string list =
    List.nth_exn key_list (Core.Random.int (List.length key_list));;
  
(* Sample choice if initial ngram is not given
  let sample_choice_no_initial (n: int) (input_file: string list) (sample_length: int) =
    print_endline (list_to_string (SGrams.sample_sequence (SGrams.ngrams n input_file) ~max_length:sample_length ~initial_ngram:(random_ngram_start (Map.keys (SGrams.ngrams n input_file)))));;
    *)
  

    
  (* MOST FREQUENT *)
  type result = { ngram : string list; frequency : int} [@@deriving to_yojson];;
  type result_list = result list [@@deriving to_yojson];;

  let get_first (pair: 'a * 'b): 'a =
    let (r1, _) = pair in
      r1;;
  
  let get_second (pair: 'a * 'b): 'b =
    let (_, r2) = pair in
      r2;;
  
  let rec compare_string_lists (first: string list) (second: string list): int = 
    match (first, second) with
    | [], [] -> 0
    | [],_ -> -1
    | _,[] -> 1
    | (h1::t1), (h2::t2) -> if ((String.compare h1 h2) > 0) then 1
                          else if (String.equal h1 h2) then compare_string_lists t1 t2
                          else  -1;;

  let compare_frequency_pairs (pair1: string list * int) (pair2: string list * int): int =
    if (get_second pair1) > (get_second pair2) then 1
    else if (get_second pair1) < (get_second pair2) then -1
    else compare_string_lists (get_first pair1) (get_first pair2);;

  let first_elements (n_most_frequent: int) (input: 'a list) : 'a list =
    List.filteri ~f:(fun index -> fun _a -> (index < n_most_frequent)) input;;

  (* Make a list of records from keyword counts *)
  let make_record_list (currList: (string list * int) list) : result_list = 
    List.map ~f:(fun elt -> { ngram = (get_first elt); frequency = (get_second elt)}) currList;;

    (*
    let most_frequent (n: int) (input_file: string list) (n_most_frequent: int) =
      (SGrams.ngrams n input_file)
      |> Map.to_alist
      |> List.map ~f:(fun pair -> ((get_first pair), Bag.length (get_second pair)))
      |> List.sort ~compare:(compare_frequency_pairs)
      |> List.rev
      |> first_elements n_most_frequent
      |> make_record_list
      |> result_list_to_yojson
      |> Yojson.Safe.to_string
      |> print_endline;;
      *)